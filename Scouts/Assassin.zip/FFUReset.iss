function main()
{
    oc ${Me.Name} - ${Time} - Ready Up PROC
    echo ${Time} - Ready up PROC
if (${Me.Ability[id,4115038578].TimeUntilReady}<=1)
	{
	OgreBotAPI:AbilityTag_ResetAllAbilityTagEmbargos[${Me.Name}]
	Echo Reset ${Me.Name}
	}
Echo Necrotic Refresh ${Me.Ability[id,4115038578].TimeUntilReady}
}