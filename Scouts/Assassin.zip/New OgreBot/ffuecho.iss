function main()
{
Echo Doing the thing ${Time}
echo FFU1 Embargo is ${OgreBotAPI.CastStack.TagEmbargoRemaining["FFU1Embargo"]} currently
echo FFU2 Embargo is ${OgreBotAPI.CastStack.TagEmbargoRemaining["FFU2Embargo"]} currently, we should be setting it to 25 from whatever it is currently.
echo FFU1 Allow is ${OgreBotAPI.CastStack.TagAllowRemaining["FFU1Allow"]} currently, changing it to 0.
echo FFU2 Allow is ${OgreBotAPI.CastStack.TagAllowRemaining["FFU2Allow"]} currently, changing it to 0.
OgreBotAPI.CastStack:HoldTag[${Me.Name}, FFU2Embargo, 25, Embargo]
OgreBotAPI.CastStack:ClearAllow[${Me.Name}, FFU1Allow]
OgreBotAPI.CastStack:ClearAllow[${Me.Name}, FFU2Allow]
    if ${OgreBotAPI.CastStack.TagEmbargoRemaining["FFU1Embargo"]} < 25
    {
        echo FFU1 Embargo is ${OgreBotAPI.CastStack.TagEmbargoRemaining["FFU1Embargo"]} currently, changing it to 25.
        OgreBotAPI.CastStack:HoldTag[${Me.Name}, FFU1Embargo, 25, Embargo]
        echo FFU1 Embargo is now ${OgreBotAPI.CastStack.TagEmbargoRemaining["FFU1Embargo"]}, which should be 25. 
    }
echo FFU2 Embargo is ${OgreBotAPI.CastStack.TagEmbargoRemaining["FFU2Embargo"]} Should be 25.
echo FFU1 Allow is ${OgreBotAPI.CastStack.TagAllowRemaining["FFU1Allow"]} Should be 0 or null.
echo FFU2 Allow is ${OgreBotAPI.CastStack.TagAllowRemaining["FFU2Allow"]} Should be 0 or null.
echo Line Break for testing.
}